// There are a row of n houses, each house can be painted with one of the three colors: red, blue or green. The cost of painting each house with a certain color is different. You have to paint all the houses such that no two adjacent houses have the same color.

// The cost of painting each house with a certain color is represented by a n x 3 cost matrix. For example, costs[0][0] is the cost of painting house 0 with color red; costs[1][2] is the cost of painting house 1 with color green, and so on... Find the minimum cost to paint all houses.

// Note:
// All costs are positive integers.

// Hide Company Tags LinkedIn
// Show Tags
// Show Similar Problems

// reference: https://segmentfault.com/a/1190000003903965
/**
 * @param {number[][]} costs
 * @return {number}
 */

 // space O(1) time O(n)
var minCost = function(costs) {
    if(!costs || costs.length === 0)   {
        return 0;
    }
    
    for(var i = 1; i < costs.length; i++) {
        // The colors that can be painted depends on the color we used for the previous houses,
        // pick the min cost from previous colors
        costs[i][0] += Math.min(costs[i-1][1], costs[i-1][2]);
        costs[i][1] += Math.min(costs[i-1][0], costs[i-1][2]);
        costs[i][2] += Math.min(costs[i-1][0], costs[i-1][1]);
    }
    
    i--;
    return Math.min.apply(null, costs[i]);
};