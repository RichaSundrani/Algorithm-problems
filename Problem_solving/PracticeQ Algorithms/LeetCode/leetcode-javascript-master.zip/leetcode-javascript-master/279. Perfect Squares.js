/**
 * @param {number} n
 * @return {number}
 */
var numSquares = function(n) {
    
};